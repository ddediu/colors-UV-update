## The data given below represent 46 repair times (in hours)for
## an airborne communication transceiver.
## Chhikara, R. S. and Folks, J. L. (1989). 
## The Inverse Gaussian Distribution.  Marcel Dekker, New York.

repairtimes <- c(0.2, 0.3, 0.5, 0.5, 0.5, 0.5, 0.6, 0.6, 0.7, 0.7, 0.7, 0.8, 0.8,
1.0, 1.0, 1.0, 1.0, 1.1, 1.3, 1.5, 1.5, 1.5, 1.5, 2.0, 2.0, 2.2,
2.5, 2.7, 3.0, 3.0, 3.3, 3.3, 4.0, 4.0, 4.5, 4.7, 5.0, 5.4, 5.4,
7.0, 7.5, 8.8, 9.0, 10.3, 22.0, 24.5)