## Mark Bebbington, Chin-Diew Lai, Ricardas Zitikis.(2007) 
## A flexible Weibull extension. 
## Reliability Engineering and System Safety, 92, 719-726. 
reactorpump <- c(0.062, 0.070, 0.101, 0.150, 0.199, 0.273, 0.347, 0.358, 0.402,
 0.491, 0.605, 0.614, 0.746, 0.954, 1.060, 1.359, 1.921, 2.160, 3.465, 4.082, 
 4.992, 5.320, 6.560)