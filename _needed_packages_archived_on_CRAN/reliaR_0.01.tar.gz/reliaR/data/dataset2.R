## Data set contains 36 months of defect-discovery times for a
## release of Controller Software consisting of about 500,000
## lines of code installed on over 100,000 controllers.
## Lyu, M. R. (1996). Handbook of Software Reliability Engineering,
## IEEE Computer Society Press, http://www.cse.cuhk.edu.hk/~lyu/book/reliability/
## Chapter 11 (DATASET2.DAT - 111 time-between-failures data)
dataset2 <- c(12,15,28,39,53,53,60,60,60,63,68,68,82,91,97,97,102,103,103,104,105,109,
109,113,125,126,131,158,165,166,166,173,183,189,193,194,202,204,214,229,230,
235,235,237,238,238,239,243,251,253,257,260,263,266,268,271,271,272,274,279,
284,288,288,291,293,299,305,308,323,323,327,328,333,336,347,349,369,389,392,
393,405,410,411,411,417,435,435,435,435,441,441,453,467,468,488,509,512,517,
558,559,573,587,644,644,655,728,734,769,783,994,1064)