context("zone utility functions")

# zones <- sets::set(sets::as.set(1L),
#                      sets::as.set(2L),
#                      sets::as.set(3L),
#                      sets::as.set(1:2),              
#                      sets::as.set(c(1L, 3L)),
#                      sets::as.set(c(2L, 3L)))
# 
# 
# zones <- sets::set(sets::as.set(1L),
#                      sets::as.set(2L),
#                      sets::as.set(3L),
#                      sets::as.set(1:2),              
#                      sets::as.set(c(1L, 3L)),
#                      sets::as.set(c(2L, 3L)),
#                      sets::as.set(c(1L, 4L)))