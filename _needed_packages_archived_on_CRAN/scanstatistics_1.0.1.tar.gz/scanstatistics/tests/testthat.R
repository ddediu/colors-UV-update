library(testthat)
library(scanstatistics)

test_check("scanstatistics")
